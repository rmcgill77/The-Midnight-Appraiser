# The Midnight Appraiser: Android build (Capacitor)

Package name: `com.ryandm96.midnightappraiser`. This is permanent once you upload to Google Play.

This folder is the whole Android wrapper. The game itself is in `site/` (the built web game). The app ships those files inside it, so it plays fully offline.

**Not yet built.** The environment this was prepared in could not download the Android SDK or npm packages, so nothing here has been compiled. The scripts were tested against a stand-in Android folder (patching, versioning, signing), but the first real build is yours to run. If a step fails, send me the error text.

## Two ways to build

### A. In the cloud with GitHub (no Android Studio, works from a phone browser)

1. Create a **private** GitHub repository.
2. Upload everything in this folder to it **except** `signing/` (that holds your key; it is not in this zip, it comes separately).
3. In the repo: Settings, Secrets and variables, Actions, New repository secret. Add four secrets from the signing files you were sent:
   - `KEYSTORE_B64`: the contents of `upload-keystore.b64.txt`
   - `KEYSTORE_PASSWORD`: `storePassword` from `keystore.properties`
   - `KEY_ALIAS`: `midnight-appraiser-upload`
   - `KEY_PASSWORD`: `keyPassword` from `keystore.properties`
4. Actions tab, "Build Android bundle", Run workflow. When it finishes (about 5 to 10 minutes), download the `midnight-appraiser-aab` artifact. Inside is the signed `.aab`.

### B. On your own computer

Needs Node 20 or newer, JDK 21, and the Android SDK (installing Android Studio gets you the SDK; set `ANDROID_HOME` to it).

1. Put the `signing/` folder (sent separately) in this folder.
2. In this folder:
   ```
   npm install
   npm run www
   npx cap add android
   npm run patch
   npx cap sync android
   npm run bundle
   npm run sign
   ```
3. The signed bundle is `dist-play/midnight-appraiser-<version>.aab`.

## Updating the game later

The app contains a copy of the game, so every game update means a new bundle and a new Play release.

1. Build the web game (`node scripts/build-site.mjs` in the game's folder) and replace `site/` with the new `dist/`.
2. Run `npm run www`, `npm run patch`, `npx cap sync android`, `npm run bundle`, `npm run sign`.
3. The version code comes from the game's version (2.5.1 is 20501), so it always goes up. Upload the new `.aab` as a new release.

## What the patch step does

- Keeps the screen on while you play and hides the system bars (swipe from an edge to show them).
- Adds the VIBRATE permission. The game's haptics (`navigator.vibrate`, already in the game, with its setting) then work in the app.
- Sets the app icon (adaptive and round) and a dark splash screen.
- Sets versionName and versionCode from the game.

## Google Play Console checklist

- Create app: name "The Midnight Appraiser", Game, Free.
- Store listing: text in `store/listing.md`, icon `store/icon-512.png`, feature graphic `store/feature-graphic-1024x500.png`, screenshots in `store/screenshots/` (1920x1080, landscape; Play wants at least 2).
- Privacy policy URL: `privacy.html` is part of the game site, so it is at `https://<your-netlify-site>/privacy.html` once the new build is deployed to Netlify. Fill in your contact email in it first.
- App content: Data safety (no data collected or shared; see `store/listing.md`), content rating questionnaire, target audience (not for children), ads (none).
- App signing: accept Play App Signing. The key made for you is the upload key, and Play holds the real signing key. If the upload key is ever lost, Play can reset it.
- Testing: a new personal developer account normally has to run a closed test with a minimum number of testers for 14 days before it can publish to production. The Console's dashboard shows the exact requirement.
- Target API level: the patch step prints what the Capacitor project targets. Play requires new apps to target a current Android version; the latest Capacitor tracks that.
